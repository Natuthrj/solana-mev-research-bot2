import os
import base64
import tempfile
import unittest

os.environ.setdefault('TELEGRAM_BOT_TOKEN', 'test-token-not-real')
os.environ.setdefault('TELEGRAM_ALLOWED_USER_IDS', '123456789')

from app.screen import inspect, reasons, indicative_spread
from app.audit import parse_mint_account
from app.store import Store

class CoreTests(unittest.TestCase):
    def sample(self, price=1.0, liquidity=20000, volume=10000, age_minutes=60):
        from datetime import datetime, timezone
        created = int((datetime.now(timezone.utc).timestamp() - age_minutes*60)*1000)
        return {
            'chainId':'solana','dexId':'testdex','pairAddress':'pair',
            'baseToken':{'address':'Mint111','symbol':'TST','name':'Test'},
            'quoteToken':{'symbol':'USDC'},'priceUsd':str(price),
            'liquidity':{'usd':liquidity},'volume':{'h24':volume},
            'pairCreatedAt':created,'priceChange':{'h1':1.2},
            'txns':{'h1':{'buys':10,'sells':5}},'fdv':100000
        }

    def test_inspect_and_basic_thresholds(self):
        x = inspect(self.sample())
        self.assertEqual(x['symbol'], 'TST')
        self.assertEqual(x['mint'], 'Mint111')
        self.assertEqual(reasons(x), [])

    def test_reject_low_liquidity_and_volume(self):
        x = inspect(self.sample(liquidity=1, volume=2))
        why = reasons(x)
        self.assertTrue(any('liquidity' in r for r in why))
        self.assertTrue(any('volume' in r for r in why))

    def test_spread_is_descriptive(self):
        spread = indicative_spread([self.sample(1), self.sample(1.1)])
        self.assertIsNotNone(spread)
        self.assertAlmostEqual(spread['spread_pct'], 10.0, places=5)
        self.assertIsNone(indicative_spread([self.sample(1)]))

    def test_parse_spl_mint_base_layout(self):
        raw = bytearray(82)
        raw[0:4] = (1).to_bytes(4, 'little')
        raw[36:44] = (123456).to_bytes(8, 'little')
        raw[44] = 6
        raw[45] = 1
        raw[46:50] = (1).to_bytes(4, 'little')
        account = {'data':[base64.b64encode(raw).decode(), 'base64']}
        result = parse_mint_account(account)
        self.assertTrue(result['mint_authority_present'])
        self.assertTrue(result['freeze_authority_present'])
        self.assertEqual(result['supply_raw'], 123456)
        self.assertEqual(result['decimals'], 6)

    def test_store_starts_paused_and_paper(self):
        with tempfile.TemporaryDirectory() as d:
            store = Store(os.path.join(d, 'test.sqlite'), 25)
            self.assertEqual(store.state('paused'), '1')
            self.assertEqual(store.state('mode'), 'paper')
            pid = store.proposal('Mint111', 'TST', 1.0, 'test')
            self.assertEqual(store.get_proposal(pid)['status'], 'pending')
            store.close_proposal(pid, 'approved_paper')
            store.log_paper(store.get_proposal(pid), 0.05, 0.01)
            self.assertEqual(store.summary()['n'], 1)
            self.assertAlmostEqual(store.summary()['net'], -0.06)

if __name__ == '__main__':
    unittest.main()
