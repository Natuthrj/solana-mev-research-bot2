# Solana MEV Research Bot — Paper-Only MVP

**This is not a live MEV bot and cannot submit swaps.** It is a safety-first research prototype with Telegram controls, market-data scanning, read-only SPL mint inspection, an indicative cross-pool price-spread report, and a paper ledger. Live transaction execution is intentionally absent.

## Current capabilities

- Telegram allowlist based on numeric user IDs.
- Starts **paused + paper-only** on every boot.
- `/scan MINT`: inspect Solana pools listed by DexScreener and apply liquidity, pair age, 24h volume, price and reported 1h activity heuristics.
- `/opportunities`: inspect a small sample of the latest DexScreener token profiles. This is **not** a complete new-token launch feed.
- `/audit MINT`: read-only Solana RPC checks for SPL mint initialization, mint/freeze authority presence, supply, and a rough top-five token-account share. This is not a full Token-2022 extension, holder-identity, LP-lock, sellability, or honeypot audit.
- `/arb MINT`: show displayed cross-pool price dispersion. This is **not executable arbitrage**: it does not build routes, estimate pool-specific swap outputs, or simulate two-sided execution.
- `/buy MINT USD`: creates a paper proposal only. `/confirm ID` logs estimated costs only; no swap is signed or sent. `/cancel ID` cancels a proposal.
- `/status`, `/balance`, `/pnl`, `/risk`, `/settings`, `/pause`, `/resume`, `/sell` (explicitly reports that execution is not implemented).
- SQLite proposal/ledger storage and automated unit tests / GitHub Actions test workflow.
- Dockerfile for a future worker deployment.

## Strategy choice for a $25 wallet

The MVP does not claim a strategy is profitable. Launch sniping has extreme latency, rug, price-impact and failed-sell risks. DEX arbitrage requires accurate executable quotes on both sides, atomic or tightly coordinated execution, low latency, and sufficient spread after priority fees/tips. Jito bundles can help deliver atomic transactions, but competitive tips can consume a small trade's expected edge. With $25, free data and paper testing are the rational first step; hosted infrastructure fees themselves can exceed expected gains.

## Run locally

Use Python 3.12+. Create a Telegram bot through [@BotFather](https://t.me/BotFather), then set `TELEGRAM_BOT_TOKEN` and your numeric `TELEGRAM_ALLOWED_USER_IDS` in a local `.env` file. Never commit `.env`.

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python -m unittest discover -s tests -v
python -m app
```

`SOLANA_RPC_URL` defaults to the public mainnet RPC. Public RPC endpoints may rate-limit or be unsuitable for production; use a dedicated provider only after reviewing its terms and costs.

## Railway deployment

This process is a Telegram polling worker. Deploy as a single replica. Configure variables from `.env.example`; mount persistent storage and set `DATABASE_PATH` to the mounted volume path before relying on the SQLite ledger. Do not add wallet secrets: this MVP has no wallet integration. A free Railway trial/plan or paid usage can change; verify the current dashboard before deployment. No deployment has been created by this repository build.

## What is not implemented

- No live buy/sell/swap transaction building or signing.
- No Jito bundle submission or tip bidding.
- No continuous on-chain launch feed / Geyser subscription.
- No full Token-2022 extension parsing, unique-holder concentration, LP-lock verification, sell simulation, or honeypot guarantee.
- No route-aware, two-sided arbitrage quote or transaction simulation.
- No true marked-to-market P&L, equity curve, or drawdown because the MVP does not hold positions.
- No historical backtest or verified profitability claim.

Before any live implementation, add a reviewed route/swap builder, quote freshness checks, sell-path simulation, RPC transaction simulation, fee and tip budgets, slippage and price-impact limits, idempotency, expiry-bound approvals, isolated signer, transaction reconciliation, and independent security review. Keep live trading disabled until all of these are tested. Never paste seed phrases/private keys into ChatGPT, Telegram, GitHub, or ordinary logs.
