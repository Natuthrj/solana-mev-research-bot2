import logging
from aiogram import Bot, Dispatcher
from aiogram.filters import Command
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from . import config as cfg
from .store import Store
from .screen import pairs_for, latest_profiles, inspect, reasons, indicative_spread
from .audit import inspect_mint
logging.basicConfig(level=logging.INFO)
log=logging.getLogger('sniper')

def usd(v): return f'${float(v):,.2f}'

async def main():
    s=Store(cfg.DB_PATH,cfg.STARTING_BALANCE)
    # Fail closed at every boot, regardless of environment.
    s.set('mode','paper'); s.set('paused','1')
    bot=Bot(cfg.TOKEN); dp=Dispatcher()
    def ok(m): return m.from_user is not None and m.from_user.id in cfg.ALLOWED
    async def deny(m): await m.answer('Not authorized.')
    @dp.message(Command('start','help'))
    async def start(m:Message):
        if not ok(m): return await deny(m)
        await m.answer('Solana Sniper — monitor + manual paper proposals\n/status /scan MINT /audit MINT /arb MINT /opportunities\n/buy MINT USD /confirm ID /cancel ID /sell MINT\n/pnl /risk /settings /balance /pause /resume\nDefault: PAUSED + PAPER. Live swaps are disabled. Never send wallet secrets here.')
    @dp.message(Command('status'))
    async def status(m:Message):
        if not ok(m): return await deny(m)
        await m.answer(f"Mode: {s.state('mode')}\nPaused: {s.state('paused')}\nLive transaction submission: DISABLED\nWallet connected: NO\nDiscovery: on-demand only; no continuous launch feed")
    @dp.message(Command('balance'))
    async def balance(m:Message):
        if not ok(m): return await deny(m)
        a=s.summary()
        await m.answer(f'Reference balance: {usd(cfg.STARTING_BALANCE)}\nPaper ledger costs recorded: {usd(a["fee"]+a["slip"])}\nThis is not a wallet balance. No wallet is connected.')
    @dp.message(Command('sell'))
    async def sell(m:Message):
        if not ok(m): return await deny(m)
        await m.answer('SELL is not implemented because this build has no swap execution or wallet integration. No transaction was sent.')
    @dp.message(Command('opportunities','discover'))
    async def opportunities(m:Message):
        if not ok(m): return await deny(m)
        try: profiles=await latest_profiles()
        except Exception as e:
            log.warning('profile lookup failed: %s',type(e).__name__)
            return await m.answer('Latest-profile lookup failed. Retry later; no trade was made.')
        if not profiles: return await m.answer('No Solana profiles returned by the data source.')
        rows=[]
        for p in profiles[:8]:
            mint=p.get('tokenAddress','')
            if not mint: continue
            try:
                pairs=await pairs_for(mint)
                xs=sorted((inspect(pair) for pair in pairs), key=lambda x:x['liquidity'], reverse=True)
            except Exception:
                continue
            if not xs: continue
            x=xs[0]; rs=reasons(x)
            rows.append(f"{'BASIC FILTER PASS' if not rs else 'REJECT / INCOMPLETE'} — {x['symbol']}\nLiquidity {usd(x['liquidity'])} | 24h vol {usd(x['volume'])} | age {'unknown' if x['age'] is None else f'{x["age"]:.0f}m'}\n{'; '.join(rs) if rs else 'Market-data thresholds only; no on-chain safety audit.'}\n{x['url']}")
        await m.answer(('Latest DexScreener token profiles — not a complete new-token feed.\n\n'+'\n\n'.join(rows))[:3900] if rows else 'No latest profiles had pair data available. No trades were made.')
    @dp.message(Command('audit'))
    async def audit(m:Message):
        if not ok(m): return await deny(m)
        a=(m.text or '').split()
        if len(a)!=2: return await m.answer('Usage: /audit SOLANA_TOKEN_MINT')
        try: x=await inspect_mint(a[1])
        except Exception as e:
            log.warning('mint audit failed: %s',type(e).__name__)
            return await m.answer('Read-only RPC mint inspection failed or address is not a recognised SPL mint. No trade was made.')
        await m.answer(f"READ-ONLY MINT CHECK\nProgram: {x['owner_program']}\nInitialized: {x['initialized']}\nMint authority present: {x['mint_authority_present']}\nFreeze authority present: {x['freeze_authority_present']}\nDecimals: {x['decimals']} | supply: {x['supply_ui']}\nTop 5 token-account share (rough, not unique holders): {'unknown' if x['largest_account_share_pct'] is None else f'{x['largest_account_share_pct']:.1f}%'}\nWARNING: {x['warning']}")
    @dp.message(Command('arb'))
    async def arb(m:Message):
        if not ok(m): return await deny(m)
        a=(m.text or '').split()
        if len(a)!=2: return await m.answer('Usage: /arb SOLANA_TOKEN_MINT')
        try: ps=await pairs_for(a[1])
        except Exception:
            return await m.answer('Market-data lookup failed. No trade was made.')
        spread=indicative_spread(ps)
        if not spread: return await m.answer('Fewer than two price-bearing pools found. No spread estimate available.')
        gross=spread['spread_pct']
        cost=cfg.SLIPPAGE*2 + (cfg.FEE/max(cfg.MAX_ORDER,0.01))*100
        await m.answer(f"INDICATIVE CROSS-POOL PRICE DISPERSION — NOT EXECUTABLE ARBITRAGE\nPools inspected: {spread['pool_count']}\nLowest displayed price: ${spread['low']['price']:.8g} on {spread['low']['dex']}\nHighest displayed price: ${spread['high']['price']:.8g} on {spread['high']['dex']}\nGross displayed spread: {gross:.3f}%\nIllustrative cost hurdle at max order: ~{cost:.2f}% (assumes two-sided slippage + one estimated fee; excludes routing, pool impact, priority fees, Jito tips and stale data)\nThis cannot confirm a tradeable profit; no transaction was built or sent.")
    @dp.message(Command('pause'))
    async def pause(m:Message):
        if not ok(m): return await deny(m)
        s.set('paused','1'); await m.answer('Paused. New proposals blocked.')
    @dp.message(Command('resume'))
    async def resume(m:Message):
        if not ok(m): return await deny(m)
        s.set('paused','0'); await m.answer('Unpaused for proposals only. This does not enable live trading.')
    @dp.message(Command('settings'))
    async def settings(m:Message):
        if not ok(m): return await deny(m)
        await m.answer(f'Reference balance {usd(cfg.STARTING_BALANCE)}\nMax proposal {usd(cfg.MAX_ORDER)}\nDaily loss stop {usd(cfg.MAX_DAILY_LOSS)}\nMax trades/day {cfg.MAX_TRADES_DAY}\nMin liquidity {usd(cfg.MIN_LIQUIDITY)}\nMin pair age {cfg.MIN_AGE} minutes\nMin 24h volume {usd(cfg.MIN_VOLUME)}\nEstimated slippage {cfg.SLIPPAGE:.2f}% (cap {cfg.MAX_SLIPPAGE:.2f}%)\nEstimated fee {usd(cfg.FEE)}\nHeuristics are not a scam guarantee.')
    @dp.message(Command('pnl'))
    async def pnl(m:Message):
        if not ok(m): return await deny(m)
        a=s.summary(); await m.answer(f'Paper ledger only\nTrades logged {a["n"]}\nNet after estimated costs {usd(a["net"])}\nEstimated fees {usd(a["fee"])}\nEstimated slippage cost {usd(a["slip"])}\nLast 24h net {usd(a["day"])}\nTrades last 24h {a["today"]}\nPending proposals {a["pending"]}\nRealized P&L is not a live wallet statement; drawdown needs position valuation.')
    @dp.message(Command('risk'))
    async def risk(m:Message):
        if not ok(m): return await deny(m)
        a=s.summary(); stop=a['day'] <= -cfg.MAX_DAILY_LOSS
        await m.answer(f'Daily net {usd(a["day"])} / loss limit -{usd(cfg.MAX_DAILY_LOSS)}\nTrades today {a["today"]}/{cfg.MAX_TRADES_DAY}\nLoss stop active: {stop}\nLive trading disabled.')
    @dp.message(Command('scan'))
    async def scan(m:Message):
        if not ok(m): return await deny(m)
        args=(m.text or '').split()
        if len(args)!=2: return await m.answer('Usage: /scan SOLANA_TOKEN_MINT')
        try: ps=await pairs_for(args[1])
        except Exception as e:
            log.warning('lookup failed: %s',type(e).__name__); return await m.answer('Market-data lookup failed; check mint address and retry.')
        if not ps: return await m.answer('No Solana pairs found for that mint.')
        xs=sorted((inspect(p) for p in ps),key=lambda x:x['liquidity'],reverse=True)
        lines=[]
        for x in xs[:3]:
            rs=reasons(x)
            age_text = 'unknown' if x['age'] is None else f"{x['age']:.1f}m"
            label = 'PASS BASIC FILTERS' if not rs else 'REJECT'
            reason_text = '; '.join(rs) if rs else 'Basic thresholds pass; no on-chain audit performed.'
            lines.append(f"{label} — {x['symbol']} ({x['name']})\nLiquidity {usd(x['liquidity'])} | 24h vol {usd(x['volume'])} | age {age_text}\nPrice ${x['price']:.8g} | 1h {x['change']:+.1f}% | buys/sells {x['buys']}/{x['sells']}\n{reason_text}\n{x['url']}")
        await m.answer('\n\n'.join(lines)[:3900])
    @dp.message(Command('buy'))
    async def buy(m:Message):
        if not ok(m): return await deny(m)
        if s.state('paused','1')=='1': return await m.answer('Bot is paused. Use /resume first.')
        a=(m.text or '').split()
        if len(a)!=3: return await m.answer('Usage: /buy SOLANA_TOKEN_MINT USD_AMOUNT')
        try: amount=float(a[2])
        except ValueError: return await m.answer('Amount must be numeric.')
        if amount<=0 or amount>cfg.MAX_ORDER: return await m.answer(f'Amount must be > $0 and <= {usd(cfg.MAX_ORDER)}.')
        if cfg.SLIPPAGE>cfg.MAX_SLIPPAGE: return await m.answer('Configured slippage exceeds cap; rejected.')
        st=s.summary()
        if st['day']<=-cfg.MAX_DAILY_LOSS: return await m.answer('Daily loss stop reached; proposals blocked.')
        if st['today']>=cfg.MAX_TRADES_DAY: return await m.answer('Daily trade cap reached.')
        try: ps=await pairs_for(a[1])
        except Exception: return await m.answer('Market-data lookup failed; rejected.')
        xs=[inspect(p) for p in ps]; xs=[x for x in xs if x['mint'].lower()==a[1].lower() and not reasons(x)]
        if not xs: return await m.answer('Rejected: no pair passed basic liquidity, age and volume filters.')
        x=max(xs,key=lambda x:x['liquidity']); pid=s.proposal(a[1],x['symbol'],amount,f"liq={x['liquidity']};vol={x['volume']}")
        kb=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text='Review proposal',callback_data=f'proposal:{pid}')]])
        await m.answer(f'PROPOSAL #{pid} — NOT A TRADE\n{x["symbol"]} | {usd(amount)}\nEstimated fee {usd(cfg.FEE)} | estimated slippage {cfg.SLIPPAGE:.2f}%\nManual confirmation required; live swap is disabled.',reply_markup=kb)
    @dp.callback_query(lambda q: q.data and q.data.startswith('proposal:'))
    async def show(q):
        if q.from_user.id not in cfg.ALLOWED: return await q.answer('Not authorized',show_alert=True)
        pid=int(q.data.split(':')[1]); p=s.get_proposal(pid)
        if not p or p['status']!='pending': return await q.answer('No longer pending',show_alert=True)
        await q.message.answer(f'Proposal #{pid}: BUY {p["symbol"]} for {usd(p["usd"])}\nMint: {p["token"]}\nTo approve paper-only, send /confirm {pid}. No live swap will be sent.')
        await q.answer()
    @dp.message(Command('confirm'))
    async def confirm(m:Message):
        if not ok(m): return await deny(m)
        a=(m.text or '').split()
        if len(a)!=2 or not a[1].isdigit(): return await m.answer('Usage: /confirm PROPOSAL_ID')
        pid=int(a[1]); p=s.get_proposal(pid)
        if not p or p['status']!='pending': return await m.answer('Proposal not found or already closed.')
        if s.state('paused','1')=='1': return await m.answer('Paused: confirmation rejected.')
        s.close_proposal(pid,'approved_paper'); s.log_paper(p,cfg.FEE,p['usd']*cfg.SLIPPAGE/100)
        await m.answer(f'Approved as PAPER ONLY. No blockchain transaction sent. Logged fee {usd(cfg.FEE)} and estimated slippage {usd(p["usd"]*cfg.SLIPPAGE/100)}.')
    @dp.message(Command('cancel'))
    async def cancel(m:Message):
        if not ok(m): return await deny(m)
        a=(m.text or '').split()
        if len(a)!=2 or not a[1].isdigit(): return await m.answer('Usage: /cancel PROPOSAL_ID')
        p=s.get_proposal(int(a[1]))
        if not p or p['status']!='pending': return await m.answer('Proposal not found or already closed.')
        s.close_proposal(int(a[1]),'cancelled'); await m.answer(f'Proposal #{a[1]} cancelled.')
    await bot.delete_webhook(drop_pending_updates=True)
    log.info('Starting in paper mode, paused')
    await dp.start_polling(bot)
