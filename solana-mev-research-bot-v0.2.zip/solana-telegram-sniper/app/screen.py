"""Public market-data helpers. Results are heuristics, not a security audit."""
from datetime import datetime, timezone
import httpx

DEX_BASE = "https://api.dexscreener.com"

async def _get_json(url: str):
    async with httpx.AsyncClient(timeout=12, headers={"User-Agent": "solana-research-bot/0.2"}) as client:
        response = await client.get(url)
        response.raise_for_status()
        return response.json()

async def pairs_for(mint: str):
    if not mint or len(mint) > 64 or any(ch.isspace() for ch in mint):
        raise ValueError("Invalid mint string")
    data = await _get_json(f"{DEX_BASE}/latest/dex/tokens/{mint}")
    return [p for p in (data.get("pairs") or []) if p.get("chainId") == "solana"]

async def latest_profiles():
    """Returns latest profiles, not a complete new-token launch feed."""
    data = await _get_json(f"{DEX_BASE}/token-profiles/latest/v1")
    return [x for x in (data or []) if x.get("chainId") == "solana"]

def _number(value, default=0.0):
    try:
        x = float(value)
        return x if x == x and abs(x) != float("inf") else default
    except (TypeError, ValueError):
        return default

def inspect(p):
    liq = _number((p.get("liquidity") or {}).get("usd"))
    vol = _number((p.get("volume") or {}).get("h24"))
    ts = p.get("pairCreatedAt")
    age = max(0, (datetime.now(timezone.utc).timestamp() - _number(ts)/1000)/60) if ts else None
    b = p.get("baseToken") or {}
    txns = p.get("txns") or {}
    h1 = txns.get("h1") or {}
    return {
        "mint": b.get("address", ""), "symbol": b.get("symbol", "?"),
        "name": b.get("name", "Unknown"), "url": p.get("url", ""),
        "dex": p.get("dexId", "unknown"), "pair": p.get("pairAddress", ""),
        "quote_symbol": (p.get("quoteToken") or {}).get("symbol", "?"),
        "liquidity": liq, "volume": vol, "age": age,
        "price": _number(p.get("priceUsd")),
        "change": _number((p.get("priceChange") or {}).get("h1")),
        "buys": int(_number(h1.get("buys"))), "sells": int(_number(h1.get("sells"))),
        "fdv": _number(p.get("fdv")),
    }

def reasons(x):
    from . import config as c
    out = []
    if not x["mint"]: out.append("missing base mint")
    if x["price"] <= 0: out.append("price unavailable")
    if x["liquidity"] < c.MIN_LIQUIDITY:
        out.append(f"liquidity ${x['liquidity']:,.0f} below ${c.MIN_LIQUIDITY:,.0f}")
    if x["volume"] < c.MIN_VOLUME:
        out.append(f"24h volume ${x['volume']:,.0f} below ${c.MIN_VOLUME:,.0f}")
    if x["age"] is None: out.append("pair age unavailable")
    elif x["age"] < c.MIN_AGE: out.append(f"pair age {x['age']:.1f}m below {c.MIN_AGE}m")
    if x["buys"] + x["sells"] == 0: out.append("no reported 1h trades")
    return out

def indicative_spread(pairs):
    """Descriptive price dispersion only; not a route-aware arbitrage quote."""
    valid = [inspect(p) for p in pairs if _number(p.get("priceUsd")) > 0]
    if len(valid) < 2:
        return None
    valid.sort(key=lambda x: x["price"])
    low, high = valid[0], valid[-1]
    spread_pct = (high["price"] / low["price"] - 1) * 100 if low["price"] else 0
    return {"low": low, "high": high, "spread_pct": spread_pct, "pool_count": len(valid)}
