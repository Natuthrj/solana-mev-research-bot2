import sqlite3, time
from contextlib import contextmanager

class Store:
    def __init__(self, path, starting):
        self.path = path
        with self.db() as c:
            c.executescript('''CREATE TABLE IF NOT EXISTS proposals(id INTEGER PRIMARY KEY AUTOINCREMENT, token TEXT, symbol TEXT, usd REAL, status TEXT, created INTEGER, note TEXT);
            CREATE TABLE IF NOT EXISTS trades(id INTEGER PRIMARY KEY AUTOINCREMENT, token TEXT, symbol TEXT, usd REAL, fee REAL, slip REAL, pnl REAL DEFAULT 0, created INTEGER);
            CREATE TABLE IF NOT EXISTS state(k TEXT PRIMARY KEY, v TEXT);''')
            c.execute("INSERT OR IGNORE INTO state VALUES('paused','1')")
            c.execute("INSERT OR IGNORE INTO state VALUES('mode','paper')")
            c.execute("INSERT OR IGNORE INTO state VALUES('starting_balance',?)", (str(starting),))
    @contextmanager
    def db(self):
        c=sqlite3.connect(self.path, timeout=10); c.row_factory=sqlite3.Row
        try: yield c; c.commit()
        finally: c.close()
    def state(self,k,default=''):
        with self.db() as c:
            r=c.execute('SELECT v FROM state WHERE k=?',(k,)).fetchone(); return r['v'] if r else default
    def set(self,k,v):
        with self.db() as c: c.execute('INSERT INTO state VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v',(k,str(v)))
    def proposal(self, token, symbol, usd, note):
        with self.db() as c:
            q=c.execute("INSERT INTO proposals(token,symbol,usd,status,created,note) VALUES(?,?,?,'pending',?,?)",(token,symbol,usd,int(time.time()),note)); return q.lastrowid
    def get_proposal(self,pid):
        with self.db() as c: return c.execute('SELECT * FROM proposals WHERE id=?',(pid,)).fetchone()
    def close_proposal(self,pid,status):
        with self.db() as c: c.execute('UPDATE proposals SET status=? WHERE id=?',(status,pid))
    def log_paper(self,p,fee,slip):
        with self.db() as c: c.execute('INSERT INTO trades(token,symbol,usd,fee,slip,pnl,created) VALUES(?,?,?,?,?,0,?)',(p['token'],p['symbol'],p['usd'],fee,slip,int(time.time())))
    def summary(self):
        with self.db() as c:
            all_=c.execute('SELECT COUNT(*) n,COALESCE(SUM(pnl-fee-slip),0) net,COALESCE(SUM(fee),0) fee,COALESCE(SUM(slip),0) slip FROM trades').fetchone()
            day=c.execute('SELECT COALESCE(SUM(pnl-fee-slip),0) net,COUNT(*) n FROM trades WHERE created>=?',(int(time.time())-86400,)).fetchone()
            pending=c.execute("SELECT COUNT(*) n FROM proposals WHERE status='pending'").fetchone()['n']
            return dict(n=all_['n'],net=all_['net'],fee=all_['fee'],slip=all_['slip'],day=day['net'],today=day['n'],pending=pending)
