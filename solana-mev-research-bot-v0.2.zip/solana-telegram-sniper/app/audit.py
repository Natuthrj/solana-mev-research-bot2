"""Read-only Solana mint checks. Not a full token safety audit."""
import base64
import httpx
from . import config as cfg

TOKEN_PROGRAMS = {
    "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA": "SPL Token Program",
    "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb": "Token-2022 Program",
}

async def rpc(method, params):
    url = cfg.SOLANA_RPC_URL
    async with httpx.AsyncClient(timeout=12) as client:
        r = await client.post(url, json={"jsonrpc":"2.0", "id":1, "method":method, "params":params})
        r.raise_for_status()
        data = r.json()
    if data.get("error"):
        raise RuntimeError("RPC request failed")
    return data.get("result")

def parse_mint_account(account):
    """Parse standard SPL mint base layout (82 bytes); extensions are not parsed."""
    if not account or not isinstance(account.get("data"), list):
        raise ValueError("Mint account data unavailable")
    raw = base64.b64decode(account["data"][0])
    if len(raw) < 82:
        raise ValueError("Account is too short to be a mint")
    mint_opt = int.from_bytes(raw[0:4], "little")
    supply = int.from_bytes(raw[36:44], "little")
    decimals = raw[44]
    initialized = bool(raw[45])
    freeze_opt = int.from_bytes(raw[46:50], "little")
    return {
        "mint_authority_present": mint_opt == 1,
        "freeze_authority_present": freeze_opt == 1,
        "supply_raw": supply,
        "decimals": decimals,
        "initialized": initialized,
        "layout_bytes": len(raw),
    }

async def inspect_mint(mint):
    result = await rpc("getAccountInfo", [mint, {"encoding":"base64", "commitment":"confirmed"}])
    value = (result or {}).get("value")
    if not value:
        raise ValueError("Mint account not found")
    owner = value.get("owner", "")
    if owner not in TOKEN_PROGRAMS:
        raise ValueError("Address is not owned by a recognised SPL token program")
    parsed = parse_mint_account(value)
    supply_result = await rpc("getTokenSupply", [mint, {"commitment":"confirmed"}])
    largest_result = await rpc("getTokenLargestAccounts", [mint, {"commitment":"confirmed"}])
    largest = (largest_result or {}).get("value") or []
    parsed["owner_program"] = TOKEN_PROGRAMS[owner]
    parsed["supply_ui"] = ((supply_result or {}).get("value") or {}).get("uiAmountString", "unknown")
    parsed["largest_token_accounts"] = len(largest)
    parsed["largest_account_share_pct"] = None
    try:
        total = float(parsed["supply_ui"])
        top = sum(float(x.get("uiAmount") or 0) for x in largest[:5])
        if total > 0:
            parsed["largest_account_share_pct"] = top / total * 100
    except (TypeError, ValueError):
        pass
    parsed["warning"] = "Largest token accounts are not the same as unique holders; LP vaults may distort concentration. Token-2022 extensions and holder identities are not fully audited."
    return parsed
