import os
from dotenv import load_dotenv
load_dotenv()

def f(name, default):
    try: return float(os.getenv(name, default))
    except (TypeError, ValueError): return float(default)

def i(name, default):
    try: return int(os.getenv(name, default))
    except (TypeError, ValueError): return int(default)

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
ALLOWED = {int(x.strip()) for x in os.getenv("TELEGRAM_ALLOWED_USER_IDS", "").split(",") if x.strip().isdigit()}
STARTING_BALANCE = f("STARTING_BALANCE_USD", 25)
MAX_ORDER = f("MAX_ORDER_USD", 2.50)
MAX_DAILY_LOSS = f("MAX_DAILY_LOSS_USD", 1.25)
MAX_TRADES_DAY = i("MAX_TRADES_PER_DAY", 3)
MIN_LIQUIDITY = f("MIN_LIQUIDITY_USD", 10000)
MIN_AGE = i("MIN_PAIR_AGE_MINUTES", 10)
MIN_VOLUME = f("MIN_24H_VOLUME_USD", 5000)
MAX_SLIPPAGE = f("MAX_ESTIMATED_SLIPPAGE_PCT", 2)
SLIPPAGE = f("ESTIMATED_SLIPPAGE_PCT", 1)
FEE = f("ESTIMATED_SWAP_FEE_USD", .05)
DB_PATH = os.getenv("DATABASE_PATH", "sniper.sqlite3")
SOLANA_RPC_URL = os.getenv("SOLANA_RPC_URL", "https://api.mainnet-beta.solana.com")
if not TOKEN or TOKEN == "replace_me": raise RuntimeError("Set TELEGRAM_BOT_TOKEN in .env")
if not ALLOWED: raise RuntimeError("Set TELEGRAM_ALLOWED_USER_IDS to your numeric Telegram user ID")
if STARTING_BALANCE <= 0 or MAX_ORDER <= 0 or MAX_ORDER > STARTING_BALANCE: raise RuntimeError("Invalid balance/order limits")
